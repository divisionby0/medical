var $ = jQuery.noConflict();

$(document).ready(function($) {

    /*
    console.log("AdminScreenSettingBootstrapFix");

    $("#contextual-help-link").click(function () {
        console.log("help clicked");
        $("#contextual-help-wrap").css("cssText", "display: block !important;");
    });

    $("#show-settings-link").click(function () {
        console.log("settings clicked");
        $("#screen-options-wrap").css("cssText", "display: block !important;");
    });
    */
});