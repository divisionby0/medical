var $ = jQuery.noConflict();

$(document).ready(function($) {
    new QuoteEditAdminView();
});
