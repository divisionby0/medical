interface IQuestionsCollection{
    getQuestions():any;
    setQuestions(value:any):void;
}
