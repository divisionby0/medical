var RendererFactoryClass = (function () {
    function RendererFactoryClass() {
    }
    RendererFactoryClass.setClass = function (value) {
        this._class = value;
    };
    RendererFactoryClass.getClass = function () {
        return this._class;
    };
    return RendererFactoryClass;
}());
//# sourceMappingURL=RendererFactoryClass.js.map