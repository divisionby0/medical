var RendererType = (function () {
    function RendererType() {
    }
    RendererType.QUESTION_RENDERER_TYPE = "QUESTION_RENDERER_TYPE";
    RendererType.ANSWER_RENDERER_TYPE = "ANSWER_RENDERER_TYPE";
    return RendererType;
}());
//# sourceMappingURL=RendererType.js.map