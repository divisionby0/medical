class RendererType{
    public static QUESTION_RENDERER_TYPE:string = "QUESTION_RENDERER_TYPE";
    public static ANSWER_RENDERER_TYPE:string = "ANSWER_RENDERER_TYPE";
}
