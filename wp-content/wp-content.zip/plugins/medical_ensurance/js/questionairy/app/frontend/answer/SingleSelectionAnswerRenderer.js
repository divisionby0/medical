var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
///<reference path="../../../questions/question/Question.ts"/>
///<reference path="TextInputAnswerRenderer.ts"/>
var SingleSelectionAnswerRenderer = (function (_super) {
    __extends(SingleSelectionAnswerRenderer, _super);
    function SingleSelectionAnswerRenderer(data, container) {
        _super.call(this, data, container);
    }
    return SingleSelectionAnswerRenderer;
}(TextInputAnswerRenderer));
//# sourceMappingURL=SingleSelectionAnswerRenderer.js.map