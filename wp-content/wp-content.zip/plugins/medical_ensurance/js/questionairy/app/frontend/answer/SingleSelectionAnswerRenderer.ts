///<reference path="../../../questions/question/Question.ts"/>
///<reference path="TextInputAnswerRenderer.ts"/>
class SingleSelectionAnswerRenderer extends TextInputAnswerRenderer{
    constructor(data:Question, container:any){
        super(data, container);
    }
}
