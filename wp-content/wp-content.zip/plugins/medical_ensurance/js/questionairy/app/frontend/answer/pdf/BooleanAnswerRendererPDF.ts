///<reference path="AnswerRendererPDF.ts"/>
///<reference path="../../../../questions/question/Question.ts"/>
class BooleanAnswerRendererPDF extends AnswerRendererPDF{
    constructor(data:Question, container:any){
        super(data, container);
    }
}
