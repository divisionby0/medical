interface  IUserAnswer{
    hasUserValue():boolean;
}
