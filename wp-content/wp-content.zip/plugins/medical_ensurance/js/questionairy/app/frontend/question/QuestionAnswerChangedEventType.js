var QuestionAnswerChangedEventType = (function () {
    function QuestionAnswerChangedEventType() {
    }
    QuestionAnswerChangedEventType.VALUE_CHANGED = "VALUE_CHANGED";
    return QuestionAnswerChangedEventType;
}());
//# sourceMappingURL=QuestionAnswerChangedEventType.js.map