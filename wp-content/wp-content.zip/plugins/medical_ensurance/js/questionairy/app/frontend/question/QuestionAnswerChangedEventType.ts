class QuestionAnswerChangedEventType{
    public static VALUE_CHANGED:string = "VALUE_CHANGED";
}
