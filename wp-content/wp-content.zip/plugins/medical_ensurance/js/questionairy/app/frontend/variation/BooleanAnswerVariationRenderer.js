var BooleanAnswerVariationRenderer = (function () {
    function BooleanAnswerVariationRenderer(data, container) {
        _super.call(this, data, container);
    }
    return BooleanAnswerVariationRenderer;
}());
//# sourceMappingURL=BooleanAnswerVariationRenderer.js.map