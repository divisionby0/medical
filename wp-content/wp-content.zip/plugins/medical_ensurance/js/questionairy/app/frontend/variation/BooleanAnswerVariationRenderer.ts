class BooleanAnswerVariationRenderer{
    constructor(data:any, container:any){
        super(data, container);
    }
}
