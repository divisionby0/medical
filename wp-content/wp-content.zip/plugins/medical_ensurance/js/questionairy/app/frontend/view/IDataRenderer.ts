interface IDataRenderer{
    setData(data:any):void;
    getData():any;
}
