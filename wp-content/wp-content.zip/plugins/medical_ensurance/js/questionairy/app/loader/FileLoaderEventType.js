var FileLoaderEventType = (function () {
    function FileLoaderEventType() {
    }
    FileLoaderEventType.LOAD_COMPLETE = "LOAD_COMPLETE";
    FileLoaderEventType.LOAD_ERROR = "LOAD_ERROR";
    return FileLoaderEventType;
}());
//# sourceMappingURL=FileLoaderEventType.js.map