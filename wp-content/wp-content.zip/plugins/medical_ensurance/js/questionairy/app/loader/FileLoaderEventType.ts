class FileLoaderEventType{
    public static LOAD_COMPLETE:string = "LOAD_COMPLETE";
    public static LOAD_ERROR:string = "LOAD_ERROR";
}
