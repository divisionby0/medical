var FileSaverEventType = (function () {
    function FileSaverEventType() {
    }
    FileSaverEventType.SAVE_COMPLETE = "SAVE_COMPLETE";
    FileSaverEventType.SAVE_ERROR = "SAVE_ERROR";
    return FileSaverEventType;
}());
//# sourceMappingURL=FileSaverEventType.js.map