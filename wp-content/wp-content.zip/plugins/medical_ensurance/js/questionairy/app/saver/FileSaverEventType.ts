class FileSaverEventType{
    public static SAVE_COMPLETE:string = "SAVE_COMPLETE";
    public static SAVE_ERROR:string = "SAVE_ERROR";
}
