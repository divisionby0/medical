interface IDestroable{
    destroy():void;
}
