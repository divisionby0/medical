///<reference path="IDestroable.ts"/>
//# sourceMappingURL=IHtmlElement.js.map