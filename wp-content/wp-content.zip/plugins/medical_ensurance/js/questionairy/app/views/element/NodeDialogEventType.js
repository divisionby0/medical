var NodeDialogEventType = (function () {
    function NodeDialogEventType() {
    }
    NodeDialogEventType.CREATE = "CREATE_NODE";
    NodeDialogEventType.REMOVE = "REMOVE_NODE";
    NodeDialogEventType.UPDATE = "UPDATE_NODE";
    return NodeDialogEventType;
}());
//# sourceMappingURL=NodeDialogEventType.js.map