class NodeDialogEventType{
    public static CREATE:string = "CREATE_NODE"; 
    public static REMOVE:string = "REMOVE_NODE"; 
    public static UPDATE:string = "UPDATE_NODE"; 
}
