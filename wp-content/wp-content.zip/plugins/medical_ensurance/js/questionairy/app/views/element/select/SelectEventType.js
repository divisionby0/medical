var SelectEventType = (function () {
    function SelectEventType() {
    }
    SelectEventType.SELECTED_ITEM_CHANGED = "SELECTED_ITEM_CHANGED";
    return SelectEventType;
}());
//# sourceMappingURL=SelectEventType.js.map