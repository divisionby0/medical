class SelectEventType{
    public static SELECTED_ITEM_CHANGED:string = "SELECTED_ITEM_CHANGED";
}
