var TextInput = (function () {
    function TextInput() {
    }
    return TextInput;
}());
//# sourceMappingURL=TextInput.js.map