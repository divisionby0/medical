var TreeViewEventType = (function () {
    function TreeViewEventType() {
    }
    TreeViewEventType.NODE_SELECTED = "NODE_SELECTED";
    TreeViewEventType.NODE_UNSELECTED = "NODE_UNSELECTED";
    TreeViewEventType.NODE_REMOVE_REQUEST = "NODE_REMOVE_REQUEST";
    TreeViewEventType.NODE_EDIT_REQUEST = "NODE_EDIT_REQUEST";
    TreeViewEventType.NODE_MOVE_UP_REQUEST = "NODE_MOVE_UP_REQUEST";
    TreeViewEventType.NODE_MOVE_DOWN_REQUEST = "NODE_MOVE_DOWN_REQUEST";
    return TreeViewEventType;
}());
//# sourceMappingURL=TreeViewEventType.js.map