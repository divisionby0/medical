class TreeViewEventType{
    public static NODE_SELECTED:string = "NODE_SELECTED";
    public static NODE_UNSELECTED:string = "NODE_UNSELECTED";
    public static NODE_REMOVE_REQUEST:string = "NODE_REMOVE_REQUEST";
    public static NODE_EDIT_REQUEST:string = "NODE_EDIT_REQUEST";
    public static NODE_MOVE_UP_REQUEST:string = "NODE_MOVE_UP_REQUEST";
    public static NODE_MOVE_DOWN_REQUEST:string = "NODE_MOVE_DOWN_REQUEST";
}
