///<reference path="../../collections/iterators/MapIterator.ts"/>
//# sourceMappingURL=ICompositeNode.js.map