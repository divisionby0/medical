///<reference path="../textAnswer/TextInputAnswer.ts"/>
class DateSelectionAnswer extends TextInputAnswer
{
    protected type:string = ObjectType.DATE_SELECTION_ANSWER;

    constructor(){
        super();
    }
}
