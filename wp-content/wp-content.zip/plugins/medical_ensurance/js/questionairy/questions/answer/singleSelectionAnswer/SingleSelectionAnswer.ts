///<reference path="../Answer.ts"/>
class SingleSelectionAnswer extends Answer{

    protected type:string = ObjectType.SINGLE_SELECTION_ANSWER;
    
    constructor(){
        super("");
    }
}
