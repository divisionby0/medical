var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
///<reference path="TextInputAnswer.ts"/>
var TextViewAnswer = (function (_super) {
    __extends(TextViewAnswer, _super);
    function TextViewAnswer() {
        _super.call(this);
        this.type = ObjectType.TEXT_VIEW_ANSWER;
    }
    return TextViewAnswer;
}(TextInputAnswer));
//# sourceMappingURL=TextViewAnswer.js.map