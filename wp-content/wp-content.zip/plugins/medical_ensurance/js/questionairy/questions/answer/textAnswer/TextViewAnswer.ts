///<reference path="TextInputAnswer.ts"/>
class TextViewAnswer extends TextInputAnswer{

    protected type:string = ObjectType.TEXT_VIEW_ANSWER;
    
    constructor(){
        super();
    }
}
