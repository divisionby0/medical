var CollectionEventType = (function () {
    function CollectionEventType() {
    }
    CollectionEventType.COLLECTION_CHANGED = "NODES_COLLECTION_CHANGED";
    return CollectionEventType;
}());
//# sourceMappingURL=CollectionEventType.js.map