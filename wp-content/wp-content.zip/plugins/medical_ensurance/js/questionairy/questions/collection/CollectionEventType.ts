class CollectionEventType{
    public static COLLECTION_CHANGED:string = "NODES_COLLECTION_CHANGED";
}
