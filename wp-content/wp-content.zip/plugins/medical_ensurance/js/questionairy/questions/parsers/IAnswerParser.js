///<reference path="../answer/Answer.ts"/>
//# sourceMappingURL=IAnswerParser.js.map