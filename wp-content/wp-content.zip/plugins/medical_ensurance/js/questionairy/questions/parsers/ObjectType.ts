class ObjectType{
    public static ANSWER:string = "answer";
    public static ANSWER_VARIATION:string = "answerVariation";
    public static QUESTION:string = "question";
    public static QUESTION_COLLECTION:string = "questionCollection";
    public static MULTIPLE_SELECTION_ANSWER:string = "multipleSelectionAnswer";
    public static SINGLE_SELECTION_ANSWER:string = "singleSelectionAnswer";
    public static BOOLEAN_ANSWER:string = "booleanAnswer";
    public static TEXT_INPUT_ANSWER:string = "textInputAnswer";
    public static TEXT_VIEW_ANSWER:string = "textViewAnswer";
    public static DATE_SELECTION_ANSWER:string = "dateSelectionAnswer";
}
