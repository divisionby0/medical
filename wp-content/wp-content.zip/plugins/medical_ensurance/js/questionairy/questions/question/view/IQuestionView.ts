interface IQuestionView{
    decorateText(text:string, type:string):string;
}
