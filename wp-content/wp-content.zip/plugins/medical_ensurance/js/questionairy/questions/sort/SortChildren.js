///<reference path="../utils/Sorter.ts"/>
var SortChildren = (function () {
    function SortChildren(children) {
        var sorter = new Sorter(children);
        sorter.sort();
    }
    return SortChildren;
}());
//# sourceMappingURL=SortChildren.js.map