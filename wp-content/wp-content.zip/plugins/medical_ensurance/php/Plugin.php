<?php

class Plugin {
    public static $name='medical_ensurance';
} 