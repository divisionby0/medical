<?php

class AgeRangeType {
    public static $range = "range";
    public static $under = "under";
    public static $over = "over";
    public static $any = "any";
} 