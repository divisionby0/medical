<?php


interface IAgeRange {
    public function getType();
    public function getFrom();
    public function getTill();
} 