<?php

class DeductibleAmount extends ValueObject{

} 