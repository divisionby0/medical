<?php

class DeductibleAmountOption {
    private $amount;
    private $surchargeOrDiscount;
    private $ageRange;
} 