<?php

class SurchargeOrDiscount {
    private $procent;
    private $benefit;
} 