<?php

class TableModel {
    private $headerText = 'Header text';

} 