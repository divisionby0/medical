<?php


interface ICollectionCoordinates {
    public function setRowId($rowId);
    public function setColumnId($columnId);
} 