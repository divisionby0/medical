<?php


class DayNumberSelect extends Select{

    // override
    protected function createContent(){
        $this->content = '<option value="1">1</option>';
    }
} 