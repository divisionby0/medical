<?php


class ApplicationTypeView
{
    public function __construct($type)
    {
        echo '<div style="display: block;">Type: <b>'.$type.'</b></div>';
    }
}