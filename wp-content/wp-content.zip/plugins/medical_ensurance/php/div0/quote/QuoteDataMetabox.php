<?php

class QuoteDataMetabox
{
    public function __construct($postId){
        //$companyBenefitsCollection = get_post_meta($postId, Constants::$benefits, true );
    }
}