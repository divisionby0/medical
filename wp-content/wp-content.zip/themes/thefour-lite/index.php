<?php
/**
 * The template part for displaying posts.
 * @package TheFour Lite
 */

get_header();?>

<section id="content" class="content left">

</section>

<?php
    new IndexPage();
?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
