var IndexPageSlider = function(){

    var $ = jQuery.noConflict();
    return{
        init:function(){
        }
    }
}
