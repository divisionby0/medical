var AddressRequestView = (function () {
    function AddressRequestView() {
    }
    return AddressRequestView;
}());
//# sourceMappingURL=AddressRequestView.js.map