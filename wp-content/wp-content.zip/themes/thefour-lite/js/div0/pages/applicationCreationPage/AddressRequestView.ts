class AddressRequestView{
    constructor(){
        
    }
}
