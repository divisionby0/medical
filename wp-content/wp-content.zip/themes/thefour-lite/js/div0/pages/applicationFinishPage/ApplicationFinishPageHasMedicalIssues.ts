///<reference path="ApplicationFinishPage.ts"/>
class ApplicationFinishPageHasMedicalIssues extends ApplicationFinishPage{
    constructor(){
        super();
    }
}
