var ApplicationType = (function () {
    function ApplicationType() {
    }
    ApplicationType.HAS_MEDICAL_ISSUES = "MEDICAL_ISSUES";
    ApplicationType.NORMAL = "NORMAL";
    return ApplicationType;
}());
//# sourceMappingURL=ApplicationType.js.map