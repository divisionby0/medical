class ApplicationType{
    public static HAS_MEDICAL_ISSUES:string = "MEDICAL_ISSUES";
    public static NORMAL:string = "NORMAL";
}
